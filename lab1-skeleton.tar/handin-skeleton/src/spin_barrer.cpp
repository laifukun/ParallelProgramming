#include <spin_barrier.h>


/************************
 * Your code here...    *
 * or wherever you like *
 ************************/