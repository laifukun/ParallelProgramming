#pragma once

#include <chrono>
#include <thread>


int __attribute__ ((noinline)) op(int a, int b, int n_loop);
int add(int a, int b, int __);