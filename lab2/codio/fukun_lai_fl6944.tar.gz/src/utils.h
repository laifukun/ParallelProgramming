#ifndef _UTILS_H_
#define _UTILS_H_
#include "defines.h"

int kmeans_rand();
void kmeans_srand(unsigned int seed);
#endif